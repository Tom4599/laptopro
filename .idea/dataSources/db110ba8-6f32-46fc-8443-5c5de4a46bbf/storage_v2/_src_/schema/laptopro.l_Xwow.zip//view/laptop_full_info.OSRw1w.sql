create view laptop_full_info as
  select `laptopro`.`laptop`.`id_laptop`           AS `id_laptop`,
         `laptopro`.`laptop`.`laptop_nom`          AS `laptop_nom`,
         `laptopro`.`laptop`.`prix`                AS `prix`,
         `laptopro`.`laptop`.`taille`              AS `taille`,
         `laptopro`.`laptop`.`definition`          AS `definition`,
         `laptopro`.`laptop`.`ram`                 AS `ram`,
         `laptopro`.`laptop`.`espace_stockage_hdd` AS `espace_stockage_hdd`,
         `laptopro`.`laptop`.`espace_stockage_ssd` AS `espace_stockage_ssd`,
         `laptopro`.`laptop`.`poids`               AS `poids`,
         `laptopro`.`laptop`.`etat`                AS `etat`,
         `laptopro`.`laptop`.`date`                AS `date`,
         `laptopro`.`laptop`.`url_photo1`          AS `url_photo1`,
         `laptopro`.`laptop`.`url_photo2`          AS `url_photo2`,
         `laptopro`.`laptop`.`url_photo3`          AS `url_photo3`,
         `laptopro`.`user`.`nom`                   AS `vendeur`,
         `laptopro`.`marque`.`nom`                 AS `marque`,
         `laptopro`.`processeur`.`nom`             AS `processeur`,
         `laptopro`.`stockage`.`nom`               AS `stockage`,
         `laptopro`.`ecran`.`nom`                  AS `ecran`,
         `laptopro`.`carte_graphique`.`nom`        AS `carte_graphique`
  from ((((((`laptopro`.`laptop` join `laptopro`.`user`) join `laptopro`.`marque`) join `laptopro`.`processeur`) join `laptopro`.`stockage`) join `laptopro`.`ecran`) join `laptopro`.`carte_graphique`)
  where ((`laptopro`.`laptop`.`id_user` = `laptopro`.`user`.`id_user`) and
         (`laptopro`.`laptop`.`id_marque` = `laptopro`.`marque`.`id_marque`) and
         (`laptopro`.`laptop`.`id_cg` = `laptopro`.`carte_graphique`.`id_cg`) and
         (`laptopro`.`laptop`.`id_stockage` = `laptopro`.`stockage`.`id_stockage`) and
         (`laptopro`.`laptop`.`id_ecran` = `laptopro`.`ecran`.`id_ecran`) and
         (`laptopro`.`laptop`.`id_processeur` = `laptopro`.`processeur`.`id_processeur`));

